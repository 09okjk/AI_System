#!/usr/bin/env python3
"""
SenseVoice MCP服务器 - 语音转文本服务
基于FunASR实现，提供符合MCP协议的语音识别功能
使用官方FastMCP库实现
"""

import os
import io
import base64
import tempfile
import logging
import argparse
import soundfile as sf
import numpy as np
from typing import Dict, Any, List, Union, Optional
from urllib.request import urlretrieve

try:
    from funasr import AutoModel
except ImportError:
    print("请先安装FunASR: pip install funasr")

# FastMCP相关导入
from mcp.server.fastmcp import FastMCP

# 配置日志
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(os.path.join(os.path.dirname(__file__), "sensvoice_server.log"))
    ]
)
logger = logging.getLogger("SenseVoiceMCPServer")

# 初始化FastMCP服务器
mcp = FastMCP("sensevoice")

# 全局变量，用于缓存已加载的模型
MODEL_CACHE = {}

# 会话缓存，用于流式处理
SESSION_CACHE = {}

class SenseVoiceProcessor:
    """语音识别处理器"""
    
    def __init__(self, model_name="paraformer-zh", vad_model="fsmn-vad", punc_model="ct-punc"):
        """
        初始化语音识别处理器
        
        Args:
            model_name: ASR模型名称或路径
            vad_model: VAD模型名称或路径，用于语音端点检测
            punc_model: 标点恢复模型名称或路径
        """
        self.model_name = model_name
        self.vad_model = vad_model
        self.punc_model = punc_model
        
        # 缓存键
        cache_key = f"{model_name}_{vad_model}_{punc_model}"
        
        # 检查模型缓存
        if cache_key in MODEL_CACHE:
            self.model = MODEL_CACHE[cache_key]
            logger.info(f"使用缓存模型: {cache_key}")
        else:
            # 加载模型
            logger.info(f"加载模型: {model_name}, VAD: {vad_model}, 标点: {punc_model}")
            
            # VAD参数设置
            vad_kwargs = {"max_single_segment_time": 60000}
            
            self.model = AutoModel(
                model=model_name,
                vad_model=vad_model,
                vad_kwargs=vad_kwargs,
                punc_model=punc_model
            )
            
            # 缓存模型
            MODEL_CACHE[cache_key] = self.model
    
    def transcribe_file(self, audio_path: str, hotwords: Optional[str] = None) -> Dict[str, Any]:
        """
        转写音频文件
        
        Args:
            audio_path: 音频文件路径
            hotwords: 热词列表，逗号分隔
            
        Returns:
            转写结果
        """
        try:
            # 调用模型
            kwargs = {}
            if hotwords:
                kwargs["hotword"] = hotwords
                
            res = self.model.generate(input=audio_path, **kwargs)
            
            # 处理结果
            # 处理不同的返回类型
            if isinstance(res, list):
                # 如果结果是列表，可能是直接返回的文本段落
                text = " ".join([str(item) for item in res if item]) if res else ""
                return {
                    "success": True,
                    "text": text,
                    "segments": [],
                    "timestamps": []
                }
            elif isinstance(res, dict):
                # 如果结果是字典，使用标准格式
                return {
                    "success": True,
                    "text": res.get("text", ""),
                    "segments": res.get("segments", []),
                    "timestamps": res.get("timestamp", [])
                }
            else:
                # 其他类型，尝试转换为字符串
                return {
                    "success": True,
                    "text": str(res),
                    "segments": [],
                    "timestamps": []
                }
        except Exception as e:
            logger.exception(f"转写音频文件失败: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def transcribe_audio_data(self, audio_data: Union[bytes, np.ndarray], 
                             sample_rate: int = 16000,
                             hotwords: Optional[str] = None) -> Dict[str, Any]:
        """
        转写音频数据
        
        Args:
            audio_data: 音频数据，可以是字节流或numpy数组
            sample_rate: 采样率
            hotwords: 热词列表，逗号分隔
            
        Returns:
            转写结果
        """
        try:
            # 如果是字节流，需要转换为numpy数组
            if isinstance(audio_data, bytes):
                # 创建临时文件
                with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_file:
                    temp_path = temp_file.name
                    temp_file.write(audio_data)
                
                try:
                    # 读取音频
                    return self.transcribe_file(temp_path, hotwords)
                finally:
                    # 清理临时文件
                    if os.path.exists(temp_path):
                        os.unlink(temp_path)
            else:
                # 创建临时文件
                with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_file:
                    temp_path = temp_file.name
                
                try:
                    # 保存音频数据到临时文件
                    sf.write(temp_path, audio_data, sample_rate)
                    # 转写
                    return self.transcribe_file(temp_path, hotwords)
                finally:
                    # 清理临时文件
                    if os.path.exists(temp_path):
                        os.unlink(temp_path)
        except Exception as e:
            logger.exception(f"转写音频数据失败: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def transcribe_streaming(self, audio_chunk: np.ndarray, cache: Dict[str, Any], 
                           is_final: bool = False, 
                           chunk_size: Union[List[int], int] = [0, 10, 5]) -> Dict[str, Any]:
        """
        流式转写音频数据
        
        Args:
            audio_chunk: 音频数据块
            cache: 缓存字典，用于保存流式处理状态
            is_final: 是否为最后一个数据块
            chunk_size: 流式处理参数，默认[0,10,5]表示延迟600ms，未来信息300ms
            
        Returns:
            转写结果
        """
        try:
            # 默认使用流式模型
            if "paraformer-zh-streaming" not in str(self.model_name):
                logger.warning("流式转写需要使用流式模型，当前模型可能不支持流式处理")
            
            encoder_chunk_look_back = 4  # 编码器回看块数
            decoder_chunk_look_back = 1  # 解码器回看块数
            
            # 检查并转换chunk_size类型
            processed_chunk_size = 200  # 默认值，200ms
            
            # 防止除以零错误，确保块大小至少为10ms
            try:
                if isinstance(chunk_size, list):
                    # 如果是列表
                    if len(chunk_size) > 0 and int(chunk_size[0]) > 0:
                        processed_chunk_size = int(chunk_size[0])
                    else:
                        # 使用安全的默认值
                        processed_chunk_size = 200
                elif isinstance(chunk_size, (int, float)) and chunk_size > 0:
                    # 如果是正数
                    processed_chunk_size = int(chunk_size)
                else:
                    # 其他情况使用默认值
                    processed_chunk_size = 200
            except (ValueError, TypeError):
                # 异常情况使用默认值
                processed_chunk_size = 200
            
            # 确保不小于10ms以避免除零错误
            processed_chunk_size = max(10, processed_chunk_size)
            
            logger.info(f"流式识别使用块大小: {processed_chunk_size}ms")
            
            # 调用流式模型
            res = self.model.generate(
                input=audio_chunk, 
                cache=cache, 
                is_final=is_final,
                chunk_size=processed_chunk_size,  # 使用处理过的块大小
                encoder_chunk_look_back=encoder_chunk_look_back,
                decoder_chunk_look_back=decoder_chunk_look_back
            )
            
            return {
                "success": True,
                "text": res["text"],
                "is_final": is_final
            }
        except Exception as e:
            logger.exception(f"流式转写失败: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    def detect_vad(self, audio_data: Union[str, np.ndarray], is_streaming: bool = False, 
                 cache: Optional[Dict[str, Any]] = None,
                 is_final: bool = False, 
                 chunk_size: int = 200) -> Dict[str, Any]:
        """
        语音端点检测
        
        Args:
            audio_data: 音频数据，可以是文件路径或numpy数组
            is_streaming: 是否为流式处理
            cache: 流式处理的缓存
            is_final: 是否为最后一个数据块
            chunk_size: 流式处理的分块大小(ms)
            
        Returns:
            检测结果
        """
        try:
            # 加载VAD模型
            if not hasattr(self, 'vad_model_instance'):
                self.vad_model_instance = AutoModel(model="fsmn-vad")
            
            if is_streaming:
                # 流式VAD
                if cache is None:
                    cache = {}
                
                res = self.vad_model_instance.generate(
                    input=audio_data, 
                    cache=cache, 
                    is_final=is_final, 
                    chunk_size=chunk_size
                )
            else:
                # 非流式VAD
                res = self.vad_model_instance.generate(input=audio_data)
            
            return {
                "success": True,
                "segments": res[0]["value"] if isinstance(res, list) and len(res) > 0 else []
            }
        except Exception as e:
            logger.exception(f"VAD检测失败: {e}")
            return {
                "success": False,
                "error": str(e)
            }
        
# 全局处理器实例
processor = None

def create_processor(model_name="paraformer-zh", vad_model="fsmn-vad", punc_model="ct-punc"):
    """创建处理器实例"""
    global processor
    if processor is None:
        processor = SenseVoiceProcessor(model_name, vad_model, punc_model)
    return processor

# 使用FastMCP装饰器定义工具
@mcp.tool()
async def transcribe_audio(
    audio_data: str, 
    is_url: bool = False, 
    is_base64: bool = False, 
    hotwords: Optional[str] = None
) -> Dict[str, Any]:
    """将音频转换为文本(语音识别)。
    
    Args:
        audio_data: 音频数据，可以是URL、本地文件路径或Base64编码的音频数据
        is_url: 音频数据是否为URL
        is_base64: 音频数据是否为Base64编码
        hotwords: 热词列表，逗号分隔，可增强这些词的识别率
    """
    global processor
    
    # 确保处理器已初始化
    if processor is None:
        processor = create_processor()
    
    try:
        # 临时文件路径
        temp_path = None
        
        try:
            # 处理音频数据
            if is_url:
                # 下载URL指向的音频
                with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_file:
                    temp_path = temp_file.name
                urlretrieve(audio_data, temp_path)
                result = processor.transcribe_file(temp_path, hotwords)
            elif is_base64:
                # 解码Base64音频数据
                audio_bytes = base64.b64decode(audio_data)
                with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_file:
                    temp_path = temp_file.name
                    temp_file.write(audio_bytes)
                result = processor.transcribe_audio_data(audio_bytes, hotwords=hotwords)
            else:
                # 直接处理本地文件路径
                if os.path.exists(audio_data):
                    result = processor.transcribe_file(audio_data, hotwords)
                else:
                    return {"success": False, "error": f"文件不存在: {audio_data}"}
            
            return result
        finally:
            # 清理临时文件
            if temp_path and os.path.exists(temp_path):
                os.unlink(temp_path)
    except Exception as e:
        logger.exception(f"处理音频转文本请求失败: {e}")
        return {"success": False, "error": str(e)}


@mcp.tool()
async def transcribe_streaming(
    audio_chunk: str, 
    is_final: bool, 
    session_id: str
) -> Dict[str, Any]:
    """流式语音识别（实时语音转文本）。
    
    Args:
        audio_chunk: 音频数据块，Base64编码
        is_final: 是否为最后一个数据块
        session_id: 会话ID，用于区分不同的语音流
    """
    global processor
    
    # 确保处理器已初始化
    if processor is None:
        processor = create_processor()
    
    try:
        # 解码Base64音频数据
        audio_bytes = base64.b64decode(audio_chunk)
        audio_data, _ = sf.read(io.BytesIO(audio_bytes))
        
        # 获取或创建会话缓存
        if session_id not in SESSION_CACHE:
            SESSION_CACHE[session_id] = {}
        
        # 流式处理
        result = processor.transcribe_streaming(
            audio_data, 
            SESSION_CACHE[session_id], 
            is_final
        )
        
        # 如果是最后一个数据块，清理会话缓存
        if is_final:
            SESSION_CACHE.pop(session_id, None)
        
        return result
    except Exception as e:
        logger.exception(f"处理流式语音识别请求失败: {e}")
        return {"success": False, "error": str(e)}

@mcp.tool()
async def detect_vad(
    audio_data: str, 
    is_url: bool = False, 
    is_base64: bool = False
) -> Dict[str, Any]:
    """语音端点检测，检测音频中的有效语音片段。
    
    Args:
        audio_data: 音频数据，可以是URL、本地文件路径或Base64编码的音频数据
        is_url: 音频数据是否为URL
        is_base64: 音频数据是否为Base64编码
    """
    global processor
    
    # 确保处理器已初始化
    if processor is None:
        processor = create_processor()
    
    try:
        # 临时文件路径
        temp_path = None
        
        try:
            # 处理音频数据
            if is_url:
                # 下载URL指向的音频
                with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_file:
                    temp_path = temp_file.name
                urlretrieve(audio_data, temp_path)
                audio_data = temp_path
            elif is_base64:
                # 解码Base64音频数据
                audio_bytes = base64.b64decode(audio_data)
                with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_file:
                    temp_path = temp_file.name
                    temp_file.write(audio_bytes)
                audio_data = temp_path
            
            # 执行VAD检测
            result = processor.detect_vad(audio_data)
            return result
        finally:
            # 清理临时文件
            if temp_path and os.path.exists(temp_path):
                os.unlink(temp_path)
    except Exception as e:
        logger.exception(f"VAD检测失败: {e}")
        return {"success": False, "error": str(e)}

def main():
    """主函数，解析命令行参数并启动服务器"""
    # 解析命令行参数
    parser = argparse.ArgumentParser(description="SenseVoice MCP服务器 - 语音转文本服务")
    parser.add_argument("--host", default="0.0.0.0", help="监听的主机地址 (默认: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8083, help="监听的端口 (默认: 8083)")
    parser.add_argument("--model", default="paraformer-zh", help="ASR模型名称 (默认: paraformer-zh)")
    parser.add_argument("--vad_model", default="fsmn-vad", help="VAD模型名称 (默认: fsmn-vad)")
    parser.add_argument("--punc_model", default="ct-punc", help="标点恢复模型名称 (默认: ct-punc)")
    parser.add_argument("--transport", default="websocket", choices=["websocket", "stdio"], 
                        help="传输方式 (默认: websocket)")
    args = parser.parse_args()
    
    # 输出服务器信息
    logger.info(f"SenseVoice MCP服务器 - 语音转文本服务")
    logger.info(f"使用模型: {args.model}, VAD: {args.vad_model}, 标点: {args.punc_model}")
    
    # 初始化处理器
    global processor
    processor = create_processor(args.model, args.vad_model, args.punc_model)
    
    # 启动MCP服务器
    if args.transport == "websocket":
        # 当前版本的FastMCP不支持websocket传输方式
        # 我们需要使用stdio传输并实现自定义WebSocket服务器
        import asyncio
        import websockets
        import json
        import sys
        import threading
        
        # 定义WebSocket处理函数
        async def handle_websocket(websocket, path):
            logger.info(f"新的WebSocket连接: {websocket.remote_address}")
            
            try:
                async for message in websocket:
                    # 解析请求
                    try:
                        request = json.loads(message)
                        logger.debug(f"接收到请求: {request}")
                        
                        # 写入标准输入
                        print(message, flush=True)
                        
                        # 等待并读取标准输出的响应
                        response = await asyncio.get_event_loop().run_in_executor(None, sys.stdin.readline)
                        
                        # 发送响应
                        await websocket.send(response)
                    except json.JSONDecodeError:
                        logger.error("请求不是有效的JSON")
                        await websocket.send(json.dumps({"error": "Invalid JSON"}))
                    except Exception as e:
                        logger.error(f"处理请求时出错: {e}")
                        await websocket.send(json.dumps({"error": str(e)}))
            except websockets.exceptions.ConnectionClosed:
                logger.info(f"WebSocket连接关闭: {websocket.remote_address}")
        
        # 启动WebSocket服务器的函数
        async def start_websocket_server():
            server = await websockets.serve(handle_websocket, args.host, args.port)
            logger.info(f"WebSocket服务器已启动: ws://{args.host}:{args.port}")
            await server.wait_closed()
        
        # 在新线程中启动WebSocket服务器
        websocket_thread = threading.Thread(
            target=lambda: asyncio.run(start_websocket_server()),
            daemon=True
        )
        websocket_thread.start()
        
        # 使用stdio传输方式启动FastMCP
        logger.info("以标准输入/输出模式启动MCP服务器")
        mcp.run(transport='stdio')
    else:
        logger.info("以标准输入/输出模式启动服务器")
        mcp.run(transport='stdio')

if __name__ == "__main__":
    main()