# SenseVoice MCP工具

这个目录用于存放语音转文本(Speech-to-Text)的MCP工具实现。使用标准的FastMCP库实现，提供符合MCP协议规范的语音识别功能。

## 目的

SenseVoice MCP工具提供语音识别功能，允许AI Agent系统处理和理解语音输入。这个工具作为一个符合MCP协议的服务运行，可以本地运行或作为远程服务被访问。

## 实现功能

- 语音文件转文本（非实时处理）
- 实时语音流转文本（流式处理）
- 语音端点检测(VAD)
- 自动添加标点符号
- 热词增强识别
- 标准MCP协议支持
  - 使用FastMCP库自动处理JSON-RPC请求
  - 支持WebSocket和标准输入/输出传输方式
  - 自动工具探索功能

## 依赖技术

- FunASR: 阿里达摩院开源的语音识别框架
- FastMCP: MCP协议的官方Python实现库
- Model Context Protocol (MCP): 用于标准化工具接口

## 安装与使用

### 1. 安装依赖

```bash
pip install "mcp[cli]" funasr soundfile numpy
```

如果您想使用国内镜像源加速下载，可以使用以下命令：

```bash
pip install "mcp[cli]" funasr soundfile numpy -i https://pypi.tuna.tsinghua.edu.cn/simple
```

FunASR是阿里达摩院开源的语音识别框架，提供了高质量的预训练模型。

### 2. 启动SenseVoice MCP服务器

```bash
# WebSocket模式（默认）
python tools/SenseVoice/sensvoice_mcp_server.py --host 0.0.0.0 --port 8083

# 或使用标准输入/输出模式（用于命令行测试）
python tools/SenseVoice/sensvoice_mcp_server.py --transport stdio
```

可选参数：

- `--host`：指定监听地址（默认：0.0.0.0）
- `--port`：指定监听端口（默认：8083）
- `--model`：指定ASR模型（默认：paraformer-zh）
- `--vad_model`：指定VAD模型（默认：fsmn-vad）
- `--punc_model`：指定标点恢复模型（默认：ct-punc）
- `--transport`：指定传输方式，可选 websocket 或 stdio（默认：websocket）

使用MCP CLI工具进行测试：

```bash
# 使用MCP CLI工具连接到WebSocket服务器
mcp --transport websocket ws://localhost:8083

# 或直接使用stdio模式
mcp --transport stdio python tools/SenseVoice/sensvoice_mcp_server.py --transport stdio
```

首次启动时，服务器会自动下载所需的模型。

### 3. 在管理界面添加SenseVoice工具

1. 启动管理界面：`npm run dev:admin`
2. 访问 [http://localhost:3000](http://localhost:3000) 并导航至"MCP工具配置"
3. 点击"添加新工具"
4. 填写表单：
   - **名称**：`sensvoice`
   - **工具类型**：选择"远程工具"
   - **WebSocket URL**：输入服务器地址，如`ws://localhost:8083`（本地）或`ws://192.168.1.100:8083`（远程）
   - **版本**：`1.0.0`
5. 点击"保存"

## 工具API

SenseVoice工具提供以下三个主要功能：

### 1. 语音转文本（非实时）

将整段音频转换为文本，支持自动检测语音片段、添加标点符号和热词增强。

示例请求（JSON-RPC 2.0格式）：

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "executeFunction",
  "params": {
    "name": "transcribe_audio",
    "arguments": {
      "audio_data": "https://example.com/audio.wav",
      "is_url": true,
      "hotwords": "FunASR,SenseVoice"
    }
  }
}
```

### 2. 流式语音识别（实时）

实时处理音频流，适用于语音助手等需要低延迟的场景。

示例请求（JSON-RPC 2.0格式）：

```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "executeFunction",
  "params": {
    "name": "transcribe_streaming",
    "arguments": {
      "audio_chunk": "BASE64_ENCODED_AUDIO_DATA",
      "is_final": false,
    "session_id": "user123"
  }
}
```

### 3. 语音端点检测（VAD）

检测音频中的有效语音片段，可用于预处理或分割长音频。

示例请求：

```json
{
  "action": "call_function",
  "name": "detect_vad",
  "arguments": {
    "audio_data": "/path/to/local/file.wav",
    "is_url": false,
    "is_base64": false
  }
}
```

## 技术细节

- 服务器使用WebSocket协议通信，符合MCP标准
- 支持多种音频输入方式：URL、本地文件路径、Base64编码
- 使用缓存机制避免重复加载模型
- 支持会话管理，可处理多用户并发请求
- 可在本地或远程机器上运行

## 扩展开发

如需扩展SenseVoice工具功能，可以：

1. 在`TOOLS`字典中添加新的工具定义
2. 在`SenseVoiceProcessor`类中实现对应的处理方法
3. 在`handle_mcp_request`函数中添加对新工具的分发处理
